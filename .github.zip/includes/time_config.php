<?php

date_default_timezone_set('America/Sao_Paulo');

?>