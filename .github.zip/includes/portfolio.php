<hr>
<section class="portfolio ">
    <div class="container text-center my-4">
        <h2>Algumas pessoas que tivemos a oportunidade de ajudar.</h2>
        <div class="row">
            <div class="col">
                <div class="ratio ratio-1x1">
                <iframe width="465" height="827" src="https://www.youtube.com/embed/MWo5PAIc54o" title="ANÚNCIO #shorts" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                </div>
            </div>
            <div class="col">
                <div class="ratio ratio-1x1">
                <iframe width="465" height="827" src="https://www.youtube.com/embed/MWo5PAIc54o" title="ANÚNCIO #shorts" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                </div>
            </div>
            <div class="col">
                <div class="ratio ratio-1x1">
                <iframe width="465" height="827" src="https://www.youtube.com/embed/MWo5PAIc54o" title="ANÚNCIO #shorts" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                </div>
            </div>
            <div class="col">
                <div class="ratio ratio-1x1">
                <iframe width="465" height="827" src="https://www.youtube.com/embed/MWo5PAIc54o" title="ANÚNCIO #shorts" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
        </div>
    </div>


</section>