<div class="row">
    <div class="col-10 m-auto">

        <h5 class="mt-3">Com anos de experiência em ajudar nossos clientes a conseguir taxa de juros mais baixas,a
            <b>MulticredBH</b>
            proporciona nossos clientes a oportunidade da diminuicao de parcelas a serem pagas,
            auxiliamos nossos clientes a conquistarem o que realmente é de direito em taxas mais baixas,
            a <b>MulticredBH</b> traz soluções que ajudam os nossos clientes a formalizarem suas dividas em minimos de
            parcelas e juros reduzidos atraves da portabilidade enseridade na lei de <b>8.078 / 1990.</b>
        </h5>
    </div>

    <div class="col-10 m-auto">
        <div class="row">
            <div class="col-xl-6 m-auto col-sm-12">
                <h1>
                    Nós somos uma empresa financeira que atua pelos meios digitais. Trabalhamos seus consignados
                    reduzindo suas taxas te ajudando a fugir dos juros abusivos que os bancos fisicos estao te forcando
                    a pagar acada novo emprestimo, sempre focado na convensao dos seus valores.
                </h1>
                <h1>
                    Converse com a nossa equipe ainda hoje e crie um plano de diminuição das taxas e juros abusivos!
                </h1>
            </div>
            <div class="col-xl-6  col-sm-12">

                <img class="img-fluid" alt="" title="MulticredBH"
                    src="https://cdn.pixabay.com/photo/2015/06/19/21/24/avenue-815297_640.jpg" style="max-height:600px" />
            </div>

        </div>
    </div>
</div>




<section class="descricao-danki3">
    <div class="container">
        <div class="box-depoimento d-none">
            <p>“Temos como parceiro estratégico nos nossos planejamento a plataforma digital. Sempre nos trazendo
                soluções inovadoras e adequadas às nossas necessidades e dos nossos clientes. Super recomendo!“</p>
            <br />
            <p><b>MulticredBH</b></p>

        </div>
    </div>
</section>