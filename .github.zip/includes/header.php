<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand rounded-circle" href="<?=base_url()?>">
            <img class="rounded-circle" src="https://scontent.fplu4-1.fna.fbcdn.net/v/t39.30808-6/301809574_110534125120893_4050571496603209680_n.jpg?_nc_cat=102&cb=99be929b-59f725be&ccb=1-7&_nc_sid=be3454&_nc_eui2=AeEQrtfbmWGys_FcEj3_C-22_uJ30wcjGOj-4nfTByMY6Bx9GgdcuxG_wua0qdJvPKOj6_kD2BNF7Ic3hF4quZ1V&_nc_ohc=w0lrSSoKwzMAX9kYO0w&_nc_ht=scontent.fplu4-1.fna&oh=00_AfD2G9kMfG3OnzAwrJapxIV3mftc2u8q3o4-EcVhzlbZ2Q&oe=64DA3AC0" class="img-fluid" style="max-height: 80px">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup"
            aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <a class="nav-link" href="<?=base_url()?>">Inicio</a>
                <a class="nav-link" href="<?=base_url()?>sobre">Sobre</a>
                <a class="nav-link" href="<?=base_url()?>servicos">Serviços</a>
                <a class="nav-link" href="<?=base_url()?>atendimento-ao-cliente">Atendimento ao
                    Cliente</a>
            </div>
           
        </div>
     
    <div >
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup" >
            <div class="navbar-nav">
                <a class="nav-link" href="<?=base_url()?>login">Login</a>
            </div>
        </div>   
    </div> 
</nav>