<div class="box">
<form action="">
    <div class="inputBox">
        <input type="E-mail" name="Email" id="E-mail" class="inputUser" required>
        <label for="E-mail" class="labelInput">E-mail</label>
    </div>
</form>
</div>